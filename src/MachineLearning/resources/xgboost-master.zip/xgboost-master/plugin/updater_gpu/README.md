# CUDA Accelerated Tree Construction Algorithms

[The XGBoost GPU documentation has moved here.](https://xgboost.readthedocs.io/en/latest/gpu/index.html)
